import StoryModel from '../models/StoryModel.js';
import HomeView from '../views/HomeView.js';

class HomePresenter {
  constructor() {
    this.view = new HomeView();
  }

  async render() {
    return this.view.render();
  }

  async afterRender() {
    this.view.initMap();
    try {
      const stories = await StoryModel.getAllStories();
      this.view.renderStories(stories, this.onStoryClick.bind(this));
      this.view.addMarkersToMap(stories);
    } catch (error) {
      this.view.showError(error.message);
    }
  }

  onStoryClick(story) {
    this.view.focusMap(story);
  }
}

export default new HomePresenter();
