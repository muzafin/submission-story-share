import CONFIG from '../config.js';
import { getToken } from '../utils/auth-token.js';

class StoryModel {
  static async getAllStories() {
    const response = await fetch(`${CONFIG.BASE_URL}/stories`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    });

    const responseJson = await response.json();
    if (!response.ok) {
      throw new Error(responseJson.message || 'Failed to fetch stories');
    }
    return responseJson.listStory;
  }

  static async getStoryDetail(id) {
    const response = await fetch(`${CONFIG.BASE_URL}/stories/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    });

    const responseJson = await response.json();
    if (!response.ok) {
      throw new Error(responseJson.message || 'Failed to fetch story detail');
    }
    return responseJson.story;
  }

  static async addStory(formData) {
    const response = await fetch(`${CONFIG.BASE_URL}/stories`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
      body: formData, // FormData automatically sets multipart/form-data boundary
    });

    const responseJson = await response.json();
    if (!response.ok) {
      throw new Error(responseJson.message || 'Failed to add story');
    }
    return responseJson;
  }
}

export default StoryModel;
